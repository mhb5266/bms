// Written by DMF313.IR
#include <Arduino.h>
#include "dfPlayer.h"

uint8_t UseHardwareSerial = 0;
static uint8_t cmd[10] = { 0X7E/*Start*/, 0xFF/*Version*/, 0x06/*Length*/, 0x00/*Command*/, 00/*Feedback*/, 00/*HighDataByte*/, 00/*LowDataByte*/, 0xFE/*HighChecksumByte*/, 0x00/*LowChecksumByte*/, 0XEF/*End*/ };

/*
DataByte = -1 ---> Dont Change This Byte
*/
void dfPlayer::sendCmd( uint8_t Command, int32_t DataByte ) {
	cmd[df_Packet_Command] = Command;
	if( DataByte == -1 ) {
		cmd[df_Packet_HiByteArgument ] = 0;
		cmd[df_Packet_LowByteArgument] = 0;
	}
	else {
		cmd[df_Packet_HiByteArgument ] = (DataByte>>8);
		cmd[df_Packet_LowByteArgument] = DataByte & 0xFF;
	}
	
	uint16_t Checksum = calcChecksum( cmd );
	
	cmd[df_Packet_HiByteCheckSum ] = (Checksum>>8);
	cmd[df_Packet_LowByteCheckSum] = Checksum & 0xFF;

	for (int i=0; i<10; i++) { //send cmd
		if( UseHardwareSerial ) (*HSerial).write (cmd[i]);
		else					(*SSerial).write (cmd[i]);
	}
}
void dfPlayer::empty( uint8_t UseHardwareSerial ) {
	if( UseHardwareSerial ) while((*HSerial).available()) (*HSerial).read();
	else					while((*SSerial).available()) (*SSerial).read();
}
int16_t dfPlayer::readCmd( uint8_t Command ) {
	uint32_t Timer = millis();
	uint8_t Data[10];

	if( UseHardwareSerial ) {
		while( (*HSerial).available() != 10 && ( millis() - Timer < 200 ) );
		if( (*HSerial).available() != 10 ) {
			empty( 1 ); return -1;
		}
		else {
			(*HSerial).readBytes( Data, 10 );
			empty( 1 );
		}
	}
	else {
		while( (*SSerial).available() != 10 && ( millis() - Timer < 200 ) );
		if( (*SSerial).available() != 10 ) {
			empty( 0 );	return -1;
		}
		else {
			(*SSerial).readBytes( Data, 10 );
			empty( 0 );
		}
	} 

	if( Data[df_Packet_StartCode] != 0X7E || Data[df_Packet_Version] != 0xFF || Data[df_Packet_Length] != 0x06 || Data[df_Packet_Command] != Command || Data[df_Packet_EndCode] != 0xEF ) return -1;

	if( !validateChecksum(Data) ) return -1;

	return ( (Data[df_Packet_HiByteArgument] << 8) | Data[df_Packet_LowByteArgument] );
}

uint16_t dfPlayer::calcChecksum( uint8_t* packet ) {
	uint16_t sum = 0;
	uint8_t i;
	for ( i = df_Packet_Version; i < df_Packet_HiByteCheckSum; i++ ) sum += packet[i];
	return -sum;
}
uint8_t dfPlayer::validateChecksum( uint8_t* in ) {
	uint16_t sum = calcChecksum(in);
	return ( sum == ((in[df_Packet_HiByteCheckSum] << 8) | in[df_Packet_LowByteCheckSum]) );
}



void dfPlayer::init( HardwareSerial* theSerial ) {
	UseHardwareSerial = 1;
	HSerial = theSerial;
	(*HSerial).begin (9600);
}
void dfPlayer::init( SoftwareSerial* theSerial ) {
	UseHardwareSerial = 0;
	SSerial = theSerial;
	(*SSerial).begin (9600);
}

void dfPlayer::pause() {
	sendCmd( 0x0E, -1 );
}
void dfPlayer::stop() {
	sendCmd( 0x16, -1 );
}

void dfPlayer::previous() {
	sendCmd( 0X02, -1 );
}
void dfPlayer::next() {
	sendCmd( 0X01, -1 );
}

void dfPlayer::play() { // Playback, یکبار آخرین آهنگ رو دوباره پخش میکنه
	sendCmd( 0X0D, -1 );
}
void dfPlayer::play(uint16_t index) { // 0-2999 
	sendCmd( 0X03, index );
}

void dfPlayer::increaseVolume() {
	sendCmd( 0X04, -1 );
}
void dfPlayer::decreaseVolume() {
	sendCmd( 0X05, -1 );
}
void dfPlayer::setVolume(uint8_t Volume) { // 0-30
	sendCmd( 0X06, Volume );
}
int8_t dfPlayer::readVolume() { // 0-30
	sendCmd( 0X43, -1 );
	return readCmd( 0X43 );
}

void dfPlayer::stereoPin( uint8_t Enable ) {
	if( Enable )	sendCmd( 0x1A, 0x00 );
	else			sendCmd( 0x1A, 0x01 );
}

void dfPlayer::setEqualization( uint8_t Type ) { // Normal=0, Pop=1, Rock=2, Jazz=3, Classic=4, Base=5 ( این مورد آخری کار نمیکنه - علشو نمیدونم)
	sendCmd( 0X07, Type );
}
int8_t dfPlayer::readEqualization() {
	sendCmd( 0X44, -1 );
	return readCmd( 0X44 );
}

int8_t dfPlayer::readPlaySource() {
	sendCmd( 0X45, -1 );
	return readCmd( 0X45 );
}
void dfPlayer::setPlaySource( uint8_t Source ) {
	sendCmd( 0x09, Source );
	delay(200);
}

void dfPlayer::gotoSleep() {
	sendCmd( 0X0A, -1 );
}
void dfPlayer::exitFromSleep( uint8_t Source ) {
	sendCmd( 0X0B, -1 );
	delay(200);
	setPlaySource( Source );
}

void dfPlayer::resetModule() {  // ریست شدن تمام تنظیمات اعمالی به ماژول
	sendCmd( 0X0C, -1 );
}

void dfPlayer::loopAll( uint8_t Enable ) { // پخش آهنگ بعدی در صورت تمام شدن آهنگ فعلی = 1 --- غیر فعال کردن این ویژگی = 0
	sendCmd( 0X11, Enable );
}

void dfPlayer::setFolderPlay( uint8_t FolderNumber, uint8_t TrackNumber ) { // 1~10
	sendCmd( 0x0F, (FolderNumber << 8) | TrackNumber );
}

/*
0 : Stop
1 : Play
2 : Pause
*/
int8_t dfPlayer::readStatus() {
	sendCmd( 0x42, -1 );
	return readCmd( 0x42 );
}

/*
باید حتما در مد مربوطه باشیم تا بتونیم تعداد آهنگ های اون حافظه ذخیره سازی رو بخونیم
*/
int16_t dfPlayer::readAllTrackCount( uint8_t device ) { // df_DEVICE_U_DISK, df_DEVICE_SD, df_DEVICE_FLASH
  switch (device) {
    case 		df_DEVICE_U_DISK:	sendCmd( 0x47, -1 );	return readCmd( 0x47 );	break;
    case 		df_DEVICE_SD:		sendCmd( 0x48, -1 );	return readCmd( 0x48 );	break;
    case		df_DEVICE_FLASH:	sendCmd( 0x49, -1 );	return readCmd( 0x49 );	break;
    default:													return 0; 				break;
  }
}
int16_t dfPlayer::readThisFolderTrackCount( uint8_t FolderNumber ) {
	sendCmd( 0x4E, FolderNumber );
	return readCmd( 0x4E );
}

int16_t dfPlayer::readCurrentFileNumber( uint8_t device ) {
	switch( device ) {
		case 		df_DEVICE_U_DISK: 	sendCmd( 0x4B, -1 );	return readCmd( 0x4B );	break;
		case 		df_DEVICE_SD: 		sendCmd( 0x4C, -1 );	return readCmd( 0x4C );	break;
		case 		df_DEVICE_FLASH:	sendCmd( 0x4D, -1 );	return readCmd( 0x4D );	break;
		default:												return -1;				break;
	}
}

void dfPlayer::loopCurrectMusic() {
	play();
	delay(100);
	sendCmd( 0x19, 0 );
}
void dfPlayer::loopThisMusic( uint8_t TrackNumber ) {
	play( TrackNumber );
	delay(100);
	sendCmd( 0x19, 0 );
}
void dfPlayer::disableLoopMusic() {
	sendCmd( 0x19, 1 );
}
/////////////////
/*
نام گزاری پوشه ها حتما باید به صورت زیر باشد
00
01
02
...
09
10
11
...
97
98
99

اگه از این تابع استفاده کنیم،  کل آهنگ های یه پوشه پشت سر هم پخش میشن
ولی دیگه نمیتونیم به صورت سراسری آهنگ ها رو پخش کنیم و باید حتما پوشه 
به پوشه این کارو انجام بدیم، مثلا اگه دستور آهنگ بعدی یا قبلی رو بزنید
فقط بین اون آهنگ های داخل پوشه جابجا میشه و به پوشه دیگه ای نمیره،
در حالی که اگه از این تابع استفاده نکنیم، بین تموم آهنگ های رم میتونیم
جابجا بشیم
*/
void dfPlayer::loopFolder( uint8_t FolderNumber ) {
  sendCmd( 0x17, FolderNumber<<8 );
}
