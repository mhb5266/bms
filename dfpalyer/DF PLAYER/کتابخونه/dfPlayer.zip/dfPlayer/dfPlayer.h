#include <Arduino.h>
#include <SoftwareSerial.h>

enum df_Packet {
	df_Packet_StartCode, 		// 0
	df_Packet_Version,			// 1
	df_Packet_Length,			// 2
	df_Packet_Command,			// 3
	df_Packet_RequestAck,		// 4
	df_Packet_HiByteArgument,	// 5
	df_Packet_LowByteArgument,	// 6
	df_Packet_HiByteCheckSum,	// 7
	df_Packet_LowByteCheckSum,	// 8
	df_Packet_EndCode,			// 9
	df_Packet_SIZE				// 10
};
enum df_PlaybackSource {
	df_DEVICE_U_DISK	=	1,
	df_DEVICE_SD		=	2,
	df_DEVICE_AUX		=	3,
	df_DEVICE_SLEEP		=	4,
	df_DEVICE_FLASH		=	5
};
enum df_Eq {
    df_Eq_Normal,	// 0
    df_Eq_Pop,		// 1
    df_Eq_Rock,		// 2
    df_Eq_Jazz,		// 3
    df_Eq_Classic,	// 4
    df_Eq_Bass		// 5
};

class dfPlayer {
public :
	void init( HardwareSerial* theSerial );
	void init( SoftwareSerial* theSerial );

	void play(); // Playback, یکبار آخرین آهنگ رو دوباره پخش میکنه
	void play( uint16_t index ); // 0-2999 

	/*
		1 = فعال کردن پخش خودکار آهنگ بعدی در صورت تمام شدن آهنگ قعلی - تا بینهایت این تکرار رخ میده
		0 = غیر فعال کردن این وِیژگی

		تمام آهنگ های توی یه فضای ذخیره سازی رو پشت سر هم پخش میکنه
		مثلا اگه رم فعال باشه تمام آهنگ هاشو پخش میکنه
		و اگه فلش فعال باشه تمام آهنگ های داخل فلش رو فعال میکنه
		
		برای خارج شدن از این پخش مداوم باید یه وضعیت استوپ ارسال کنیم
	*/
	void loopAll( uint8_t Enable );

	void loopCurrectMusic();
	void loopThisMusic( uint8_t TrackNumber );
	void disableLoopMusic();
	/////////////////
	/*
	نام گزاری پوشه ها حتما باید به صورت زیر باشد
	00
	01
	02
	...
	09
	10
	11
	...
	97
	98
	99
	
	برای خارج شدن از این پخش مداوم باید یه وضعیت استوپ ارسال کنیم
	*/
	void loopFolder( uint8_t FolderNumber );

	void setFolderPlay( uint8_t FolderNumber, uint8_t TrackNumber );

    void pause();
    void stop();

    void next();
    void previous();

	void increaseVolume();
	void decreaseVolume();
	void setVolume(uint8_t Volume); // 0-30
	int8_t readVolume();

	void setEqualization( uint8_t Type ); // Normal=0, Pop=1, Rock=2, Jazz=3, Classic=4, Base=5
	int8_t readEqualization();

	int8_t readStatus();

	/*
	برای خارج شدن از حالت اسلیپ باید ماژول رو ریست کنیم به کمک تابع
	exitFromSleep()

	این کار تاثیری در مد زیر ندارد و در صورت استفاده از مد زیر این تابع تاثیری روش نداره
	ولی حالت فلش و رم رو میبره به مد اسلیپ
	AUX
	*/
	void gotoSleep();
	void exitFromSleep( uint8_t Source );

	void resetModule(); // ریست شدن تمام تنظیمات اعمالی به ماژول

	int16_t readAllTrackCount( uint8_t device ); // DFPLAYER_DEVICE_U_DISK, DFPLAYER_DEVICE_SD, DFPLAYER_DEVICE_FLASH
	int16_t readThisFolderTrackCount( uint8_t FolderNumber );

	int16_t readCurrentFileNumber( uint8_t device );

	void stereoPin( uint8_t Enable );

	void setPlaySource( uint8_t Source );
	int8_t readPlaySource();

	// Error
	// 0x3F : Send initialization parameters 
	// 0X10 : تنظیم گین صدا - هر چی در عمل تست کردم جواب نداد
	// 0x40 : Returns an error, request retransmission 
	// 0x41 : reply - پاسخ به چی؟
	// 0X46 : نسخه نرم افزار - بدرد عمه خدا بیامرزم هم نمیخوره ^_^

private :
	void sendCmd( uint8_t Command, int32_t DataByte );
	void empty( uint8_t UseHardwareSerial );
	int16_t readCmd( uint8_t Command );

	uint8_t validateChecksum( uint8_t* in );
	uint16_t calcChecksum( uint8_t* packet );

	HardwareSerial* HSerial;
	SoftwareSerial* SSerial;
};