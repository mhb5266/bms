  /*******************************************************************************/
  //  Author:HOSSEIN GHIASVAND
  //  Date: 1398/03/07
  //  WEBSITE : https://avr-city.ir
  //
  /*******************************************************************************/
#include "TM1637.h"
#include <Arduino.h>
static int8_t TubeTab[] = {
//  XGFEDCBA
 0B00111111                                             //0
,0B00000110                                             //1
,0B01011011                                             //2
,0B01001111                                             //3
,0B01100110                                             //4
,0B01101101                                             //5
,0B01111101                                             //6
,0B00000111                                             //7
,0B01111111                                             //8
,0B01101111                                             //9
,0B01110111                                             //A    10
,0B01111100                                             //b    11
,0B00111001                                             //C    12
,0B01011110                                             //D    13
,0B01111001                                             //E    14
,0B01110001                                             //F    15
,0B00111101                                             //G    16
,0B01110110                                             //H    17
,0B00110000                                             //I    18
,0B00001110                                             //J    19
,0B00111000                                             //L    20
,0B01010100                                             //n    21
,0B01011100                                             //o    22
,0B01110011                                             //P    23
,0B01010000                                             //r    24
,0B00011100                                             //u    25
,0B01111000                                             //t    26
,0B00111110                                             //U    27
,0B00000000                                             //off  28 space
,0B01000000                                             //-    29
,0B00001000                                             //_    30
,0B00001111                                             //]    31
,0B00111001                                             //[    32
,0B01111011                                             //e    33
,0B01011111                                             //a    34
,0B01100111                                             //q    35
,0B01011000                                             //c    36
,0B01101110                                             //y    37
,0B01100011                                             //*    38  Degree
,0B00110000                                             //l    39
,0B01110100                                             //h    40
,0B00010000                                             //i    41
};

uint8_t TM1637::table_str(uint8_t ch)
{
uint8_t h;
switch (ch) {   
         case '0' : h = 0; break;
         case '1' : h = 1;break;
         case '2' : h = 2;break;
         case '3' : h = 3;break;
         case '4' : h = 4;break;
         case '5' : h = 5;break;
         case '6' : h = 6;break;
         case '7' : h = 7;break;
         case '8' : h = 8;break;
         case '9' : h = 9;break;
         case 'A' : h = 10;break;
         case 'a' : h = 34;break;
         case 'B' : h = 11;break;
         case 'b' : h = 11;break;
         case 'C' : h = 12;break;
         case 'c' : h = 36;break;
         case 'D' : h = 13;break;
         case 'd' : h = 13;break;
         case 'E' : h = 14;break;
         case 'F' : h = 15;break;
         case 'G' : h = 16;break;
         case 'H' : h = 17;break;
         case 'I' : h = 18;break;
         case 'J' : h = 19;break;
         case 'L' : h = 20;break;
         case 'U' : h = 27;break;
         case 'S' : h = 5;break;
         case 'y' : h = 37;break;
         case 'Y' : h = 37;break;
         case 'n' : h = 21;break;
         case 'O' : h = 0;break;
         case 'o' : h = 22;break;
         case 'p' : h = 23;break;
         case 'q' : h = 35;break;
         case 'r' : h = 24;break;
         case 't' : h = 26;break;
         case 'u' : h = 25;break;
         case 'e' : h = 33;break;
         case ' ' : h = 28;break;
         case '-' : h = 29;break;
         case '_' : h = 30;break;
         case ']' : h = 31;break;
         case '[' : h = 32;break;
         case '*' : h = 38;break; 
         case 'l' : h = 39;break;   
         case 'h' : h = 40;break;
	 case 'i' : h = 41;break;     
         default:h = 28;
    };
return h;
};

TM1637::TM1637(uint8_t Clk, uint8_t Data)
{
  Clkpin = Clk;
  Datapin = Data;
  pinMode(Clkpin,OUTPUT);
  pinMode(Datapin,OUTPUT);
}

void TM1637::writeByte(int8_t wr_data)
{
  uint8_t i,count1;   
  for(i=0;i<8;i++)        //sent 8bit data
  {
    digitalWrite(Clkpin,LOW);      
    if(wr_data & 0x01)digitalWrite(Datapin,HIGH);//LSB first
    else digitalWrite(Datapin,LOW);
	delayMicroseconds(3);
    wr_data >>= 1;      
    digitalWrite(Clkpin,HIGH);
	delayMicroseconds(3);
      
  }  
  digitalWrite(Clkpin,LOW); //wait for the ACK
  digitalWrite(Datapin,HIGH);
  digitalWrite(Clkpin,HIGH);     
  pinMode(Datapin,INPUT);
  while(digitalRead(Datapin))    
  { 
    count1 +=1;
    if(count1 == 200)//
    {
     pinMode(Datapin,OUTPUT);
     digitalWrite(Datapin,LOW);
     count1 =0;
    }
    pinMode(Datapin,INPUT);
  }
  pinMode(Datapin,OUTPUT);
  
}
//send start signal to TM1637
void TM1637::start(void)
{
  digitalWrite(Clkpin,HIGH);//send start signal to TM1637
  digitalWrite(Datapin,HIGH);
 // delayMicroseconds(2);
  digitalWrite(Datapin,LOW); 
  digitalWrite(Clkpin,LOW); 
} 
//End of transmission
void TM1637::stop(void)
{
  digitalWrite(Clkpin,LOW);
 // delayMicroseconds(2);
  digitalWrite(Datapin,LOW);
//  delayMicroseconds(2);
  digitalWrite(Clkpin,HIGH);
 // delayMicroseconds(2);
  digitalWrite(Datapin,HIGH); 
}

void TM1637::begin(void)
{
  
  BlankingFlag = 1;
  DecPoint = 3;
  brightness(7);
  delayscroll(300);
  clearDisplay();

  
}

//display function.Write to full-screen.
void TM1637::display(int8_t DispData[])
{
  int8_t SegData[4];
  uint8_t i;
  for(i = 0;i < 4;i ++)
  {
    SegData[i] = DispData[i];
  }
  coding(SegData);
  start();          //start signal sent to TM1637 from MCU
  writeByte(ADDR_AUTO);//
  stop();           //
  start();          //
  writeByte(STARTADDR);//
  for(i=0;i < 4;i ++)
  {
    writeByte(SegData[i]);        //
  }
  stop();           //
  start();          //
  writeByte(_BRIGHTNESS);//
  stop();            //
}
//***************************************************
void TM1637::display(String str)
{
  int8_t SegData[4];
  uint8_t i;
  for(i = 0;i <= 3;i ++)
  {
     SegData[i]=table_str(str[i]);
   }
    display(SegData);
}
//**************************************************
void TM1637::scroll(String str)
{
  int8_t SegData[4];
  uint8_t i=0;
  uint8_t j=0;
  for(i = 0;i <= str.length();i ++)
  {
   for (j=0 ; j <= 3 ;j ++)
   {
     SegData[j]=table_str(str[j+i]);
   }
    display(SegData);
    delay(_DELAY_SCROLL);
  }
}
//******************************************
void TM1637::display(uint8_t BitAddr,int8_t DispData)
{
  if(BitAddr>=1 || BitAddr <=4){
  int8_t SegData;
  BitAddr-=1;
  SegData= coding(DispData);
  start();          //start signal sent to TM1637 from MCU
  writeByte(ADDR_FIXED);
  stop();           //
  start();          //
  writeByte(BitAddr|0xc0);
  writeByte(SegData);
  stop();            //
  start();          //
  writeByte(_BRIGHTNESS);
  stop();            //
  };
}

void TM1637::display(double Decimal)
{
  int16_t temp;
  if(Decimal > 9999)return;
  else if(Decimal < -999)return;
  uint8_t i = 3;
  if(Decimal > 0)
  {
	for( ;i > 0; i --)
	{
	  if(Decimal < 1000)Decimal *= 10;
	  else break;
	}
	temp = (int)Decimal;
	if((Decimal - temp)>0.5)temp++;
  }
   else
  {
	for( ;i > 1; i --)
	{
	  if(Decimal > -100)Decimal *= 10;
	  else break;
	}
	temp = (int)Decimal;
	if((temp - Decimal)>0.5)temp--;
  }
  DecPoint = i;
  
 // Serial.println(Decimal);
  BlankingFlag = 0;
  display(temp);
   
}

void TM1637::display(int16_t Decimal)
{
  int8_t temp[4];
  if((Decimal > 9999)||(Decimal < -999))return;
  if(Decimal < 0)
  {
	temp[0] = INDEX_NEGATIVE_SIGN;
	Decimal = abs(Decimal);
	temp[1] = Decimal/100;
    Decimal %= 100;
    temp[2] = Decimal / 10;
    temp[3] = Decimal % 10;
	if(BlankingFlag)
	{
	  if(temp[1] == 0)
	  { 
	    temp[1] = INDEX_BLANK;
	    if(temp[2] == 0) temp[2] = INDEX_BLANK;
	  }
	}
  }
  else
  {
    temp[0] = Decimal/1000;
	Decimal %= 1000;
    temp[1] = Decimal/100;
    Decimal %= 100;
    temp[2] = Decimal / 10;
    temp[3] = Decimal % 10;
	if(BlankingFlag)
	{
	  if(temp[0] == 0)
	  { 
	    temp[0] = INDEX_BLANK;
	    if(temp[1] == 0) 
	    {
	      temp[1] = INDEX_BLANK;
		  if(temp[2] == 0) temp[2] = INDEX_BLANK;
	    }
	  }
	}
  }
  BlankingFlag = 1;
  display(temp);
  
}

void TM1637::clearDisplay(void)
{
  display(0x00,0x7f);
  display(0x01,0x7f);
  display(0x02,0x7f);
  display(0x03,0x7f);  
}

//Whether to light the clock point ":".
//To take effect the next time it displays.
void TM1637::point(boolean PointFlag)
{
   _PointFlag = PointFlag;
}

void TM1637::brightness( uint8_t BR)
{
uint8_t b=0; 
b= BR & 0x07;
if (b)
{
b = b | 0x08;
}
b += 0x80;
 _BRIGHTNESS=b;
}

 void TM1637::delayscroll(uint16_t SC)
 {
  _DELAY_SCROLL=SC;
 }

void TM1637::coding(int8_t DispData[])
{
  uint8_t PointData;
  if(_PointFlag == POINT_ON)PointData = 0x80;
  else PointData = 0; 
  for(uint8_t i = 0;i < 4;i ++)
  {
    if(DispData[i] == 0x7f)DispData[i] = 0x00;
    else DispData[i] = TubeTab[DispData[i]] + PointData;
  }
  if(DecPoint != 3)
  {
  	DispData[DecPoint] += 0x80;
   	DecPoint = 3;
  }
}
int8_t TM1637::coding(int8_t DispData)
{
  uint8_t PointData;
  if(_PointFlag == POINT_ON)PointData = 0x80;
  else PointData = 0; 
  if(DispData == 0x7f) DispData = 0x00 + PointData;//The bit digital tube off
  else DispData = TubeTab[DispData] + PointData;
  return DispData;
}
/*void TM1637::coding(float Decimal,DispData[])
{
  uint16_t int_part;
  if(Decimal > 9999)return;
  else if(Decimal < -999)return;
  if(Decimal > 0)
  {
	uint8_t i = 0;
	for(i < 3; i ++)
	{
	  if(Decimal < 1000)Decimal *= 10;
	  else break;
	}
	
  }
}*/
